<?php
require __DIR__ . '/auth.php';

$_SESSION = [];
session_destroy();

header ('location: login.php');
exit;