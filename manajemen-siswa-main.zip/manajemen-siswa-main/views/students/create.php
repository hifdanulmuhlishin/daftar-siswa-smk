<?php require __DIR__ . '/../layouts/header.php'; ?>

<style>
    /* Background halaman */
    .student-form-page {
        padding: 30px;
        background: #f5f6fc;
        min-height: 450px;
        border-radius: 12px;
    }

    /* Judul halaman */
    .form-heading {
        font-size: 28px;
        font-weight: 700;
        color: #292d50;
        margin: 0 0 8px;
    }

    .form-description {
        color: #85899d;
        font-size: 14px;
        margin-bottom: 25px;
    }

    /* Card form */
    .student-form-card {
        background: #ffffff;
        max-width: 800px;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 4px 18px rgba(0,0,0,0.06);
    }

    .form-section-title {
        color: #5145e8;
        font-size: 17px;
        font-weight: 700;
        margin: 0 0 22px;
        padding-bottom: 13px;
        border-bottom: 1px solid #eeeeF5;
    }

    /* Grid input */
    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    .form-group {
        margin-bottom: 5px;
    }

    .form-group.full-width {
        grid-column: 1 / -1;
    }

    .form-group label {
        display: block;
        color: #41445c;
        font-size: 14px;
        font-weight: 600;
        margin-bottom: 9px;
    }

    .form-group input {
        width: 100%;
        padding: 13px 14px;
        border: 1px solid #e1e3ed;
        border-radius: 9px;
        outline: none;
        box-sizing: border-box;
        font-size: 14px;
        color: #333;
        transition: 0.3s;
        background: #fff;
    }

    .form-group input:focus {
        border-color: #5145e8;
        box-shadow: 0 0 0 3px rgba(81,69,232,0.10);
    }

    .form-group input::placeholder {
        color: #b0b2bf;
    }

    /* Jenis kelamin */
    .gender-container {
        display: flex;
        gap: 15px;
        flex-wrap: wrap;
    }

    .gender-option {
        display: flex;
        align-items: center;
        gap: 9px;
        padding: 12px 17px;
        border: 1px solid #e1e3ed;
        border-radius: 9px;
        cursor: pointer;
        font-size: 14px;
        color: #555;
        transition: 0.3s;
    }

    .gender-option:hover {
        background: #f3f1ff;
        border-color: #5145e8;
    }

    .gender-option input {
        width: auto;
        accent-color: #5145e8;
    }

    /* Tombol */
    .form-buttons {
        display: flex;
        gap: 12px;
        margin-top: 30px;
        padding-top: 22px;
        border-top: 1px solid #eeeeF5;
        flex-wrap: wrap;
    }

    .btn-save {
        background: linear-gradient(135deg, #693bff, #004cfc);
        color: white;
        border: none;
        padding: 13px 25px;
        border-radius: 9px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.3s;
    }

    .btn-save:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(80,65,220,0.25);
    }

    .btn-cancel {
        background: #eef0f6;
        color: #555;
        text-decoration: none;
        padding: 13px 25px;
        border-radius: 9px;
        font-size: 14px;
        font-weight: 600;
        transition: 0.3s;
    }

    .btn-cancel:hover {
        background: #dfe1eb;
    }

    /* Tampilan HP */
    @media (max-width: 768px) {
        .student-form-page {
            padding: 18px;
        }

        .student-form-card {
            padding: 20px;
        }

        .form-heading {
            font-size: 23px;
        }

        .form-grid {
            grid-template-columns: 1fr;
        }

        .form-group.full-width {
            grid-column: auto;
        }
    }
</style>

<div class="student-form-page">

    <h1 class="form-heading">Tambah Siswa</h1>

    <p class="form-description">
        Silakan lengkapi formulir berikut untuk menambahkan data siswa baru.
    </p>

    <div class="student-form-card">

        <h3 class="form-section-title">
            Informasi Data Siswa
        </h3>

        <form action="create.php" method="POST">

            <div class="form-grid">

                <div class="form-group">
                    <label>NIS</label>
                    <input
                        type="text"
                        name="nis"
                        placeholder="Masukkan NIS siswa"
                        required
                    >
                </div>

                <div class="form-group">
                    <label>Nama Lengkap</label>
                    <input
                        type="text"
                        name="name"
                        placeholder="Masukkan nama lengkap"
                        required
                    >
                </div>

                <div class="form-group">
                    <label>Tempat Lahir</label>
                    <input
                        type="text"
                        name="birth_place"
                        placeholder="Masukkan tempat lahir"
                    >
                </div>

                <div class="form-group">
                    <label>Tanggal Lahir</label>
                    <input
                        type="date"
                        name="birth_date"
                    >
                </div>

                <div class="form-group full-width">

                    <label>Jenis Kelamin</label>

                    <div class="gender-container">

                        <label class="gender-option">
                            <input
                                type="radio"
                                name="gender"
                                value="L"
                                required
                            >
                            Laki-laki
                        </label>

                        <label class="gender-option">
                            <input
                                type="radio"
                                name="gender"
                                value="P"
                            >
                            Perempuan
                        </label>

                    </div>

                </div>

                <div class="form-group">
                    <label>Kelas</label>
                    <input
                        type="text"
                        name="class_name"
                        placeholder="Contoh: 14"
                        required
                    >
                </div>

                <div class="form-group">
                    <label>Jurusan</label>
                    <input
                        type="text"
                        name="major"
                        placeholder="Contoh: RPL"
                        required
                    >
                </div>

            </div>

            <div class="form-buttons">

                <button type="submit" class="btn-save">
                    ✓ Simpan Data
                </button>

                <a href="index.php" class="btn-cancel">
                    Kembali / Batal
                </a>

            </div>

        </form>

    </div>

</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>