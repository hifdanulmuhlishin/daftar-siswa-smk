
<?php require __DIR__ . '/../layouts/header.php'; ?>

<style>
    .detail-container {
        max-width: 750px;
        margin: 50px auto;
        padding: 20px;
    }

    .detail-card {
        background: #ffffff;
        border-radius: 18px;
        padding: 35px;
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
        border: 1px solid #e5e7eb;
    }

    .detail-title {
        font-size: 28px;
        color: #3730a3;
        margin-bottom: 8px;
    }

    .detail-subtitle {
        color: #64748b;
        margin-bottom: 30px;
    }

    .student-info {
        display: flex;
        align-items: center;
        padding: 17px;
        margin-bottom: 13px;
        background: #f8fafc;
        border-radius: 12px;
        border-left: 4px solid #4f46e5;
    }

    .student-info strong {
        width: 120px;
        color: #475569;
    }

    .student-info span {
        color: #1e293b;
        font-weight: 600;
    }

    .back-button {
        display: inline-block;
        margin-top: 20px;
        padding: 12px 22px;
        background: linear-gradient(135deg, #7c3aed, #2563eb);
        color: white;
        text-decoration: none;
        border-radius: 10px;
        font-weight: 600;
        transition: 0.3s;
    }

    .back-button:hover {
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(79, 70, 229, 0.3);
    }

    @media (max-width: 600px) {
        .detail-container {
            margin: 20px auto;
            padding: 12px;
        }

        .detail-card {
            padding: 22px;
        }

        .student-info strong {
            width: 95px;
        }
    }
</style>

<div class="detail-container">

    <div class="detail-card">

        <h1 class="detail-title">Detail Siswa</h1>
        <p class="detail-subtitle">
            Informasi lengkap data siswa SMK Miftahul Khair
        </p>

        <div class="student-info">
            <strong>NIS</strong>
            <span><?= htmlspecialchars($student['nis']) ?></span>
        </div>

        <div class="student-info">
            <strong>Nama</strong>
            <span><?= htmlspecialchars($student['name']) ?></span>
        </div>

        <div class="student-info">
            <strong>Kelas</strong>
            <span><?= htmlspecialchars($student['class_name']) ?></span>
        </div>

        <div class="student-info">
            <strong>Jurusan</strong>
            <span><?= htmlspecialchars($student['major']) ?></span>
        </div>

        <a href="index.php" class="back-button">
            ← Kembali ke Daftar Siswa
        </a>

    </div>

</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
