
<?php require __DIR__ . '/../layouts/header.php'; ?>

<style>
/* ===== HALAMAN EDIT SISWA ===== */

.edit-page {
    max-width: 950px;
    margin: 45px auto;
    padding: 0 20px;
    font-family: 'Segoe UI', Arial, sans-serif;
    color: #263248;
}

.edit-card {
    background: #ffffff;
    padding: 35px 40px;
    border-radius: 18px;
    box-shadow: 0 8px 30px rgba(31, 41, 55, 0.08);
    border: 1px solid #edf0f7;
}

.edit-header {
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 1px solid #edf0f7;
}

.edit-header h1 {
    font-size: 27px;
    color: #1f4de4;
    margin: 0 0 8px;
    font-weight: 700;
}

.edit-header p {
    color: #8791a5;
    font-size: 14px;
    margin: 0;
}

/* Form */

.edit-form {
    display: flex;
    flex-direction: column;
    gap: 22px;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 9px;
}

.form-group label,
.gender-title {
    font-size: 14px;
    font-weight: 600;
    color: #374151;
}

.form-group input[type="text"] {
    width: 100%;
    box-sizing: border-box;
    padding: 13px 15px;
    border: 1px solid #dce2ed;
    border-radius: 9px;
    font-size: 14px;
    color: #263248;
    background: #fafbff;
    outline: none;
    transition: 0.3s;
}

.form-group input[type="text"]:focus {
    border-color: #5365f2;
    background: #ffffff;
    box-shadow: 0 0 0 4px rgba(83, 101, 242, 0.10);
}

/* Jenis Kelamin */

.gender-options {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.gender-option {
    display: flex;
    align-items: center;
    gap: 9px;
    padding: 12px 18px;
    border: 1px solid #dce2ed;
    border-radius: 9px;
    cursor: pointer;
    font-size: 14px;
    color: #475569;
    transition: 0.3s;
    background: #fafbff;
}

.gender-option:hover {
    border-color: #0b24e6;
    background: #f3f4ff;
}

.gender-option input {
    accent-color: #5365f2;
    width: 16px;
    height: 16px;
}

/* Tombol */

.form-actions {
    display: flex;
    gap: 12px;
    margin-top: 10px;
    padding-top: 22px;
    border-top: 1px solid #edf0f7;
}

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 12px 25px;
    border-radius: 9px;
    font-size: 14px;
    font-weight: 600;
    text-decoration: none;
    border: none;
    cursor: pointer;
    transition: 0.3s;
}

.btn-update {
    color: white;
    background: linear-gradient(135deg, #6542f5, #044eee);
    box-shadow: 0 4px 12px rgba(79, 70, 229, 0.22);
}

.btn-update:hover {
    transform: translateY(-2px);
    box-shadow: 0 7px 17px rgba(79, 70, 229, 0.3);
}

.btn-cancel {
    color: #64748b;
    background: #f1f5f9;
}

.btn-cancel:hover {
    background: #e2e8f0;
    color: #334155;
}

/* Responsif */

@media (max-width: 600px) {
    .edit-page {
        margin: 25px auto;
        padding: 0 14px;
    }

    .edit-card {
        padding: 25px 20px;
    }

    .edit-header h1 {
        font-size: 23px;
    }

    .gender-options {
        flex-direction: column;
        gap: 10px;
    }

    .form-actions {
        flex-direction: column;
    }

    .btn {
        width: 100%;
        box-sizing: border-box;
    }
}
</style>

<div class="edit-page">

    <div class="edit-card">

        <div class="edit-header">
            <h1>Edit Data Siswa</h1>
            <p>Silakan perbarui informasi data siswa melalui formulir berikut.</p>
        </div>

        <form action="update.php?id=<?= htmlspecialchars((string)$student['id'], ENT_QUOTES, 'UTF-8') ?>"
              method="POST"
              class="edit-form">

            <div class="form-group">
                <label for="nis">Nomor Induk Siswa (NIS)</label>
                <input
                    type="text"
                    id="nis"
                    name="nis"
                    value="<?= htmlspecialchars($student['nis']) ?>"
                    placeholder="Masukkan NIS siswa"
                    required
                >
            </div>

            <div class="form-group">
                <label for="name">Nama Lengkap Siswa</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    value="<?= htmlspecialchars($student['name']) ?>"
                    placeholder="Masukkan nama lengkap"
                    required
                >
            </div>

            <div class="form-group">
                <span class="gender-title">Jenis Kelamin</span>

                <div class="gender-options">

                    <label class="gender-option">
                        <input
                            type="radio"
                            name="gender"
                            value="L"
                            <?= $student['gender'] === 'L' ? 'checked' : '' ?>
                            required
                        >
                        Laki-laki
                    </label>

                    <label class="gender-option">
                        <input
                            type="radio"
                            name="gender"
                            value="P"
                            <?= $student['gender'] === 'P' ? 'checked' : '' ?>
                        >
                        Perempuan
                    </label>

                </div>
            </div>

            <div class="form-group">
                <label for="class_name">Kelas</label>
                <input
                    type="text"
                    id="class_name"
                    name="class_name"
                    value="<?= htmlspecialchars($student['class_name']) ?>"
                    placeholder="Contoh: XI"
                    required
                >
            </div>

            <div class="form-group">
                <label for="major">Jurusan</label>
                <input
                    type="text"
                    id="major"
                    name="major"
                    value="<?= htmlspecialchars($student['major']) ?>"
                    placeholder="Contoh: RPL"
                    required
                >
            </div>

            <div class="form-actions">

                <button type="submit" class="btn btn-update">
                    Simpan Perubahan
                </button>

                <a href="index.php" class="btn btn-cancel">
                    Batal
                </a>

            </div>

        </form>

    </div>

</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
