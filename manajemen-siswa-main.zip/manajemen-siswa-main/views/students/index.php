
<?php require 'views/layouts/header.php'; ?>

<style>
    /* Area utama */
    .student-content {
        padding: 30px;
        background: #f5f6fc;
        min-height: 450px;
        border-radius: 12px;
    }

    /* Judul */
    .student-title {
        font-size: 28px;
        font-weight: 700;
        color: #292d50;
        margin: 0 0 8px;
    }

    .student-subtitle {
        color: #85899d;
        font-size: 14px;
        margin-bottom: 25px;
    }

    /* Notifikasi sukses */
    .success-message {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
        padding: 13px 18px;
        margin-bottom: 20px;
        border-radius: 9px;
        font-size: 14px;
    }

    /* Bagian tombol dan pencarian */
    .student-toolbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 15px;
        margin-bottom: 20px;
        flex-wrap: wrap;
    }

    .btn-add {
        display: inline-block;
        background: linear-gradient(135deg, #693bff, #2862ed);
        color: white;
        padding: 12px 20px;
        text-decoration: none;
        border-radius: 9px;
        font-size: 14px;
        font-weight: 600;
        transition: 0.3s;
    }

    .btn-add:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(80, 65, 220, 0.3);
    }

    .search-input {
        padding: 12px 15px;
        border: 1px solid #e0e2ec;
        border-radius: 9px;
        outline: none;
        width: 250px;
        font-size: 13px;
    }

    .search-input:focus {
        border-color: #5145e8;
        box-shadow: 0 0 0 3px rgba(81, 69, 232, 0.1);
    }

    /* Tabel */
    .table-card {
        background: white;
        padding: 20px;
        border-radius: 13px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        overflow-x: auto;
    }

    .student-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 700px;
    }

    .student-table thead {
        background: linear-gradient(135deg, #693bff, #2862ed);
        color: white;
    }

    .student-table th {
        padding: 16px 13px;
        text-align: left;
        font-size: 13px;
        font-weight: 600;
    }

    .student-table th:first-child {
        border-radius: 8px 0 0 0;
    }

    .student-table th:last-child {
        border-radius: 0 8px 0 0;
    }

    .student-table td {
        padding: 15px 13px;
        border-bottom: 1px solid #eeeef4;
        color: #44485e;
        font-size: 13px;
    }

    .student-table tbody tr:nth-child(even) {
        background: #f8f8ff;
    }

    .student-table tbody tr:hover {
        background: #eeeeff;
        transition: 0.2s;
    }

    /* Tombol aksi */
    .action-btn {
        display: inline-block;
        padding: 7px 11px;
        border-radius: 6px;
        text-decoration: none;
        font-size: 12px;
        font-weight: 600;
        margin: 2px;
        transition: 0.2s;
    }

    .btn-detail {
        background: #e0eaff;
        color: #0051ff;
    }

    .btn-edit {
        background: #fff2d5;
        color: #b7791f;
    }

    .btn-delete {
        background: #ffe1e1;
        color: #dc2626;
    }

    .action-btn:hover {
        opacity: 0.75;
        transform: translateY(-1px);
    }

    .empty-message {
        text-align: center;
        color: #999;
        padding: 25px;
    }

    /* Responsif */
    @media (max-width: 768px) {
        .student-content {
            padding: 18px;
        }

        .student-toolbar {
            align-items: stretch;
            flex-direction: column;
        }

        .search-input {
            width: 100%;
            box-sizing: border-box;
        }

        .student-title {
            font-size: 23px;
        }

        .table-card {
            padding: 12px;
        }
    }
</style>

<div class="student-content">

    <h1 class="student-title">Daftar Siswa</h1>

    <p class="student-subtitle">
        Selamat datang di halaman pengelolaan data siswa SMK Miftahul Khair.
    </p>

    <?php if (!empty($success)): ?>
        <div class="success-message">
            ✓ <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <div class="student-toolbar">

        <a href="create.php" class="btn-add">
            + Tambah Siswa
        </a>

        <input
            type="text"
            id="searchStudent"
            class="search-input"
            placeholder="Cari nama atau NIS siswa..."
        >

    </div>

    <div class="table-card">

        <table class="student-table" id="studentTable">

            <thead>
                <tr>
                    <th>No</th>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>Jenis Kelamin</th>
                    <th>Kelas</th>
                    <th>Jurusan</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>

                <?php if (!empty($students)): ?>

                    <?php foreach ($students as $index => $student): ?>

                        <tr>
                            <td><?= $index + 1 ?></td>

                            <td>
                                <?= htmlspecialchars($student['nis']) ?>
                            </td>

                            <td>
                                <strong>
                                    <?= htmlspecialchars($student['name']) ?>
                                </strong>
                            </td>

                            <td>
                                <?= htmlspecialchars($student['gender']) ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($student['class_name']) ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($student['major']) ?>
                            </td>

                            <td>
                                <a
                                    href="student.php?id=<?= $student['id'] ?>"
                                    class="action-btn btn-detail">
                                    Detail
                                </a>

                                <a
                                    href="edit.php?id=<?= $student['id'] ?>"
                                    class="action-btn btn-edit">
                                    Edit
                                </a>

                                <a
                                    href="delete.php?id=<?= $student['id'] ?>"
                                    class="action-btn btn-delete"
                                    onclick="return confirm('Apakah Anda yakin ingin menghapus siswa ini?')">
                                    Hapus
                                </a>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="7" class="empty-message">
                            Belum ada data siswa.
                        </td>
                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

<script>
    // Fitur pencarian siswa
    document.getElementById('searchStudent').addEventListener('keyup', function() {

        let keyword = this.value.toLowerCase();

        let rows = document.querySelectorAll('#studentTable tbody tr');

        rows.forEach(function(row) {

            let data = row.textContent.toLowerCase();

            row.style.display = data.includes(keyword) ? '' : 'none';

        });

    });
</script>

<?php require 'views/layouts/footer.php'; ?>
