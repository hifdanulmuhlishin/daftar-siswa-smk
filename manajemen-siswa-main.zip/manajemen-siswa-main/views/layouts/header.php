<?php
$currentpage= basename($_SERVER['PHP_SELF']);
$isDaftar = in_array($currentpage, ['index.php', 'student.php', 'edit.php']);
$isTambah = $currentpage === 'create.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Siswa</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<nav class="navbar">
    <a href="index.php" class="navbar-brand">
            <span class="brand-title">SMK MIFTAHUL KHAIR</span>
            <span class="brand-sub">manajemen Siswa</span>
    </a>
    <div class="navbar-menu">
         <a href="index.php" class="<?=$isDaftar ?'active' : '' ?>">Daftar siswa</a>
         <a href="create.php" class="<?=$isTambah ?'active' : '' ?>">+ tambah siswa</a>
         <a href="logout.php" class="logout" onclick="return confirm('yakin ingin keluar?')">
    logout (<?= htmlspecialchars($_SESSION['username'] ??'')?>)
       </a>
    </div>
</nav class="navbar">
</body>
</html>