<footer class="footer">
    <p class="footer-title">SMK MIFTAHUL KHAIR</P>
    <P class="footer-text">
        &copy; <?= date('Y') ?> manajemen siswa. semua hak dilindungi.
</p>
</footer>

</body> 
 
</html>