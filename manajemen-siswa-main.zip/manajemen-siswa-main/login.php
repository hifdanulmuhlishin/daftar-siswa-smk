
<?php

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/config/database.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare(
        "SELECT * FROM users WHERE username = :username LIMIT 1"
    );

    $stmt->execute([
        'username' => $username
    ]);

    $user = $stmt->fetch();

    if (
        $user &&
        password_verify($password, $user['password'])
    ) {

        session_regenerate_id(true);

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];

        header('Location: index.php');
        exit;

    } else {
        $error = 'Username atau password salah.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login - manajemen_siswa</title>
    <link rel="stylesheet" href="style.css">
    <style>
         *{ box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background:linear-gradient(135deg, #1e3a8a, #2563eb);
            font-family: "segoe UL", areal, sans-serif;
      } 
      .login-card 
      {
        width: 100%;
        max-width: 380px;
        background: #f7e2e2;
        padding: 32px;
        border-radius: 14px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.25);
    }
    .login-card h1 {
        marngin: 0;
        text-align: center;
        font-size: 20px;
        color:  #000000;

    }

    .login-card .sub {
        text-align: center;
        margin: 4px 0 24px;
        font-size: 13px;
        color: #6b7280;

    }
    .login-card label {
        display: block;
        font-size: 13px;
        font-weight: 600;
        color: #374151;
        margin-bottom: 6px;

    }
    .login-card input {
        width: 100%;
        padding:10px 12px;
        margin-bottom: 16px;
        border: 1px solid  #504d4d; 
        border-radius: 8px;
        font-size: 14px;

    }
    .login-card input:focus {
        outline: none;
        border-color:  #1159e9;
        box-Shadow: 0 0 0 3px rgba(37, 99, 235, 0.2);

    }
    .login-card button {
        width: 100%;
        padding: 11px;
        border: none;
        border-radius: 8px;
        background: #1511e7;
        color: #ffffff;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;

    }

    .login-card button:hover {
        background: #2244b3;
    }
    .error{
    
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 16px;
        font-size: 13px;
    
    }    

    
    </style>
</head>
<body>
    
<div class="login-card">
    <h1>SMK MIFTAHUL KHAIR</h1>
    <P class="sub">login manajemen siswa </P>
    <?php if($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif;?>
    <form method="post" action="login.php">
        <label for="username">username</label>
        <input type="text" id="username" name="username" required autofocus>
        <label for="password">pasword</label>
        <input type="password" id="password" name="password" required>
        <button type="submit">login</button>
    </form>
</div>
</body>
</html>
