<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$halamanbebas = [
    'login.php',
    'logout.php',
    'buat_admin.php'
];

$halamansaatIni = basename($_SERVER['PHP_SELF']);

if (
    !in_array($halamansaatIni, $halamanbebas) &&
    empty($_SESSION['user_id'])
) {
    header('Location: login.php');
    exit;
}