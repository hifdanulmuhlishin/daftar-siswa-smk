<?php
require __DIR__ . '/config/database.php';
$jumlah = (int) $pdo->query("SELECT COUNT(*)FROM users")->fetchcolumn();
if ($jumlah > 0) {
    echo "akun admin sudah ada. hapus file buat_admin.php ini.";
    exit;

}

$pesan = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST["password"] ??'';
    if ($username === '' || strlen($password)< 6) {
        $pesan='username wajib di isi dan password minimal 6 karakter.';
    } else {
        $stmt= $pdo->prepare("INSERT INTO users (username, password) VALUES (:username, :password)");
    $stmt->execute([
        'username' => $username,
        'password' => password_hash($password, PASSWORD_DEFAULT),
    ]);
    echo "akun berhasil dibuat. <a href='login.php'>ke halaman login</a>. setelah itu HAPUS file buat_admin.php";
    exit;
    }
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>buat admin</title>
</head>
<body>
  <h1>buat akun admin</h1>  
  <?php if ($pesan): ?>
    <p style="color:#a12d2d;"><?= htmlspecialchars($pesan) ?></p>
<?php endif; ?>

<form method="POST">
    <p>username: <input type="text" name="username" required></p>
    <p>password: <input type="password" name="password" required></p>
    <button type="submit">buat akun</button>
  </form>
</body>
</html>
